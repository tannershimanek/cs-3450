class Character:
    def __init__(self):
        self.weaponBehavior = None
    
    def setWeapon(self, weapon):
        self.weaponBehavior = weapon
    
    def getWeapon(self):
        return self.weaponBehavior
    
    def fight(self):
        pass


class King(Character):
    def fight(self):
        print('The King is fighting')
        Character.getWeapon(self).useWeapon()


class Queen(Character):
    def fight(self):
        print('The Queen is fighting')
        Character.getWeapon(self).useWeapon()


class Knight(Character):
    def fight(self):
        print('The Knight is fighting')
        Character.getWeapon(self).useWeapon()


class Troll(Character):
    def fight(self):
        print('The Troll is fighting')
        Character.getWeapon(self).useWeapon()


class WeaponBehavior:
    def useWeapon(self, w):
        print(w)


class SwordBehavior(WeaponBehavior):
    def useWeapon(self):
        return super().useWeapon('Swinging a sword')


class AxeBehavior(WeaponBehavior):
    def useWeapon(self):
        return super().useWeapon('Chopping with an Axe')


class KnifeBehavior(WeaponBehavior):
    def useWeapon(self):
        return super().useWeapon('Cutting with knife')


class BowAndArrowBehavior(WeaponBehavior):
    def useWeapon(self):
        return super().useWeapon('Shooting with a bow and arrow')


king = King()
king.setWeapon(BowAndArrowBehavior())
king.fight()
print()

queen = Queen()
queen.setWeapon(KnifeBehavior())
queen.fight()
print()

knight = Knight()
knight.setWeapon(SwordBehavior())
knight.fight()
print()

troll = Troll()
troll.setWeapon(AxeBehavior())
troll.fight()
print()
